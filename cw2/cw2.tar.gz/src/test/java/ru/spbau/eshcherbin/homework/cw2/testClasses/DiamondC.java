package ru.spbau.eshcherbin.homework.cw2.testClasses;

public class DiamondC {
    public DiamondA dependency;

    public DiamondC(DiamondA dependency) {
        this.dependency = dependency;
    }
}
