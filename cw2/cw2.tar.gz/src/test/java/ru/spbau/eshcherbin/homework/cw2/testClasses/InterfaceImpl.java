package ru.spbau.eshcherbin.homework.cw2.testClasses;

public class InterfaceImpl implements Interface {
}
