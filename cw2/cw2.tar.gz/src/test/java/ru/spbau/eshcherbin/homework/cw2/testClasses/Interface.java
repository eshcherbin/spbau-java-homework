package ru.spbau.eshcherbin.homework.cw2.testClasses;

public interface Interface {
}
