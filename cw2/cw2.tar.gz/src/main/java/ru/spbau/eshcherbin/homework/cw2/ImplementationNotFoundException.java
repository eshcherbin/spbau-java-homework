package ru.spbau.eshcherbin.homework.cw2;

/**
 * An exception that is thrown if no candidates for instantiation are found during Injector.initialize
 */
public class ImplementationNotFoundException extends Exception {
}
