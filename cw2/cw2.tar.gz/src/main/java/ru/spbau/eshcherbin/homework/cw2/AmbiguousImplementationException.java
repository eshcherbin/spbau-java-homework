package ru.spbau.eshcherbin.homework.cw2;

/**
 * An exception that is thrown if several candidates for instantiation are found during Injector.initialize
 */
public class AmbiguousImplementationException extends Exception {
}
