package ru.spbau.eshcherbin.homework.cw2;

/**
 * An exception that is thrown if a cyclic dependency is found during Injector.initialize
 */
public class InjectionCycleException extends Exception {
}
